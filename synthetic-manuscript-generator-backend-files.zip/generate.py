﻿from pathlib import Path
import random
import yaml
import numpy as np
import cv2

from PIL import Image, ImageDraw, ImageFont, ImageFilter

from src.generators.background_generator import ManuscriptBackgroundGenerator


ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config" / "config.yaml"


# ============================================================
# CONFIG
# ============================================================

def load_config():
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ============================================================
# CORPUS
# ============================================================

def load_corpus(path: Path):
    text = path.read_text(encoding="utf-8").strip()

    if not text:
        raise ValueError(f"Corpus is empty: {path}")

    passages = [
        block.strip()
        for block in text.split("\n\n")
        if block.strip()
    ]

    if not passages:
        raise ValueError(f"No passages found: {path}")

    return passages


# ============================================================
# SPLIT
# ============================================================

def choose_split(index):
    if index <= 85:
        return "train"
    elif index <= 95:
        return "validation"
    return "test"


# ============================================================
# TEXT PREPARATION
# ============================================================

def prepare_lines(passages, rng, target_lines=16):
    """
    Build a fuller manuscript page by combining multiple
    corpus passages while preserving every original character.
    """

    selected = []

    # Randomly choose several different passages.
    count = min(len(passages), rng.randint(3, 6))

    indexes = list(range(len(passages)))
    rng.shuffle(indexes)

    for idx in indexes[:count]:
        passage = passages[idx]

        for line in passage.splitlines():
            line = line.strip()

            if line:
                selected.append(line)

    # If corpus has too few lines, repeat selection,
    # but never alter the actual text.
    while len(selected) < target_lines:
        passage = rng.choice(passages)

        for line in passage.splitlines():
            line = line.strip()

            if line:
                selected.append(line)

            if len(selected) >= target_lines:
                break

    return selected[:target_lines]


# ============================================================
# FONT
# ============================================================

def load_font(font_path, size):
    if not font_path.exists():
        raise FileNotFoundError(
            f"Font not found: {font_path}\n"
            f"Please place a Devanagari TTF font at this location."
        )

    return ImageFont.truetype(str(font_path), size)


# ============================================================
# TEXT WIDTH
# ============================================================

def text_width(draw, text, font):
    bbox = draw.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0]


# ============================================================
# HIGHLIGHT
# ============================================================

def add_highlight(draw, x, y, width, height, rng):
    """
    Adds subtle manuscript-style red/orange highlighting.
    It does not modify the underlying text.
    """

    if rng.random() > 0.18:
        return

    padding_x = rng.randint(5, 14)
    padding_y = rng.randint(2, 6)

    draw.rounded_rectangle(
        [
            x - padding_x,
            y - padding_y,
            x + width + padding_x,
            y + height + padding_y,
        ],
        radius=5,
        fill=(
            rng.randint(145, 205),
            rng.randint(55, 100),
            rng.randint(25, 55),
        ),
        outline=None,
    )


# ============================================================
# RED MANUSCRIPT MARK
# ============================================================

def add_red_marker(draw, x, y, height, rng):
    """
    Traditional-looking red vertical/curved marker.
    """

    if rng.random() > 0.35:
        return

    marker_x = max(8, x - rng.randint(20, 45))

    draw.line(
        [
            (marker_x, y),
            (marker_x + rng.randint(-2, 3), y + height),
        ],
        fill=(
            rng.randint(125, 185),
            rng.randint(25, 65),
            rng.randint(20, 45),
        ),
        width=rng.randint(2, 4),
    )


# ============================================================
# SIDE ANNOTATION
# ============================================================

def add_side_annotation(
    image,
    font,
    text,
    y,
    rng,
):
    """
    Small marginal manuscript note.
    """

    draw = ImageDraw.Draw(image)

    margin_x = rng.randint(55, 95)

    # Use a smaller font.
    side_size = max(22, font.size // 2)

    try:
        side_font = ImageFont.truetype(
            font.path,
            side_size,
        )
    except Exception:
        side_font = font

    draw.text(
        (margin_x, y),
        text,
        font=side_font,
        fill=(
            rng.randint(90, 145),
            rng.randint(25, 65),
            rng.randint(20, 45),
        ),
    )


# ============================================================
# MANUSCRIPT TEXT RENDERER
# ============================================================

def render_manuscript(
    image,
    lines,
    font_path,
    rng,
    margin=100,
):
    """
    Render exact source text with:
    - large manuscript-like writing
    - irregular x positions
    - slight vertical variation
    - red markings
    - highlighted regions
    - marginal notes
    - multiple text blocks
    """

    draw = ImageDraw.Draw(image)

    width, height = image.size

    # Large readable manuscript text.
    font_size = rng.randint(52, 68)

    font = load_font(font_path, font_size)

    # Keep the page inside safe boundaries.
    left = margin + rng.randint(10, 35)
    right = width - margin - 25

    current_y = rng.randint(80, 115)

    metadata = []

    # Different line spacing creates natural irregularity.
    base_spacing = rng.randint(16, 28)

    for line_number, text in enumerate(lines):

        # ----------------------------------------------------
        # Estimate width
        # ----------------------------------------------------

        bbox = draw.textbbox(
            (0, 0),
            text,
            font=font,
        )

        line_width = bbox[2] - bbox[0]
        line_height = bbox[3] - bbox[1]

        # ----------------------------------------------------
        # If line is too wide, use slightly smaller font
        # ----------------------------------------------------

        current_font = font

        if line_width > right - left:

            smaller_size = max(
                42,
                int(font_size * 0.88),
            )

            current_font = load_font(
                font_path,
                smaller_size,
            )

            bbox = draw.textbbox(
                (0, 0),
                text,
                font=current_font,
            )

            line_width = bbox[2] - bbox[0]
            line_height = bbox[3] - bbox[1]

        # ----------------------------------------------------
        # Irregular horizontal position
        # ----------------------------------------------------

        jitter_x = rng.randint(-15, 22)

        x = left + jitter_x

        # Prevent overflow.
        if x + line_width > right:
            x = right - line_width

        if x < 35:
            x = 35

        # ----------------------------------------------------
        # Slight vertical irregularity
        # ----------------------------------------------------

        y_jitter = rng.randint(-3, 5)

        y = current_y + y_jitter

        # ----------------------------------------------------
        # Highlight behind selected lines
        # ----------------------------------------------------

        if rng.random() < 0.18:

            padding_x = rng.randint(5, 15)
            padding_y = rng.randint(2, 6)

            draw.rounded_rectangle(
                [
                    x - padding_x,
                    y - padding_y,
                    x + line_width + padding_x,
                    y + line_height + padding_y,
                ],
                radius=4,
                fill=(
                    rng.randint(145, 190),
                    rng.randint(50, 90),
                    rng.randint(25, 50),
                ),
            )

        # ----------------------------------------------------
        # Red marginal marker
        # ----------------------------------------------------

        add_red_marker(
            draw,
            x,
            y,
            line_height,
            rng,
        )

        # ----------------------------------------------------
        # Ink colour variation
        # ----------------------------------------------------

        ink_color = (
            rng.randint(38, 75),
            rng.randint(25, 52),
            rng.randint(15, 35),
        )

        # ----------------------------------------------------
        # Draw exact text
        # ----------------------------------------------------

        draw.text(
            (x, y),
            text,
            font=current_font,
            fill=ink_color,
        )

        # ----------------------------------------------------
        # Metadata
        # ----------------------------------------------------

        metadata.append(
            {
                "text": text,
                "x": int(x),
                "y": int(y),
                "width": int(line_width),
                "height": int(line_height),
                "rotation": 0.0,
                "font_size": int(current_font.size),
                "ink_opacity": 255,
            }
        )

        # ----------------------------------------------------
        # Occasional marginal annotation
        # ----------------------------------------------------

        if rng.random() < 0.16:

            add_side_annotation(
                image=image,
                font=current_font,
                text=rng.choice(
                    [
                        "॥",
                        "श्री",
                        "ॐ",
                        "इति",
                        "॥ श्री ॥",
                    ]
                ),
                y=max(40, y),
                rng=rng,
            )

        # ----------------------------------------------------
        # Advance line
        # ----------------------------------------------------

        current_y += (
            line_height
            + base_spacing
            + rng.randint(-4, 7)
        )

        # Stop safely before bottom.
        if current_y > height - 100:
            break

    return metadata


# ============================================================
# MANUSCRIPT ARTIFACTS
# ============================================================

def add_manuscript_artifacts(image, rng):
    """
    Adds subtle physical manuscript artifacts:
    stains, faded patches, wrinkles and grain.
    """

    width, height = image.size

    # --------------------------------------------------------
    # Faint stains
    # --------------------------------------------------------

    overlay = Image.new(
        "RGBA",
        image.size,
        (0, 0, 0, 0),
    )

    draw = ImageDraw.Draw(overlay)

    for _ in range(rng.randint(8, 18)):

        x = rng.randint(0, width)
        y = rng.randint(0, height)

        radius = rng.randint(20, 90)

        alpha = rng.randint(8, 25)

        draw.ellipse(
            [
                x - radius,
                y - radius,
                x + radius,
                y + radius,
            ],
            fill=(
                rng.randint(75, 120),
                rng.randint(45, 80),
                rng.randint(20, 50),
                alpha,
            ),
        )

    overlay = overlay.filter(
        ImageFilter.GaussianBlur(18)
    )

    image = Image.alpha_composite(
        image.convert("RGBA"),
        overlay,
    ).convert("RGB")

    # --------------------------------------------------------
    # Fine paper grain
    # --------------------------------------------------------

    arr = np.asarray(image).astype(np.int16)

    noise = np.random.default_rng(
        rng.randint(0, 10_000_000)
    ).normal(
        0,
        2.2,
        arr.shape[:2],
    )

    arr = arr + noise[..., None]

    arr = np.clip(
        arr,
        0,
        255,
    ).astype(np.uint8)

    image = Image.fromarray(arr)

    # --------------------------------------------------------
    # Very subtle blur
    # --------------------------------------------------------

    image = image.filter(
        ImageFilter.GaussianBlur(0.25)
    )

    return image


# ============================================================
# ANNOTATION
# ============================================================

def save_annotation(
    path,
    image_id,
    script,
    source_text,
    metadata,
    background_type,
):
    lines = [
        f"# {image_id}",
        "",
        "## Ground Truth Text",
        "",
        source_text,
        "",
        "## Metadata",
        "",
        f"- Script: {script}",
        f"- Image: {image_id}.png",
        f"- Background: {background_type}",
        f"- Text Regions: {len(metadata)}",
        "",
        "## Text Regions",
        "",
    ]

    for i, block in enumerate(metadata, 1):

        lines.extend(
            [
                f"### Region {i}",
                "",
                f"- Text: `{block['text']}`",
                f"- X: {block['x']}",
                f"- Y: {block['y']}",
                f"- Width: {block['width']}",
                f"- Height: {block['height']}",
                f"- Rotation: {block['rotation']}",
                f"- Font Size: {block['font_size']}",
                f"- Ink Opacity: {block['ink_opacity']}",
                "",
            ]
        )

    path.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


# ============================================================
# PREVIEW GENERATION
# ============================================================

def generate_preview(config):

    seed = config["project"]["seed"]

    rng = random.Random(seed)

    width = config["image"]["width"]
    height = config["image"]["height"]

    corpus_path = (
        ROOT
        / "input"
        / "devanagari"
        / "corpus.txt"
    )

    font_path = (
        ROOT
        / config["scripts"]["devanagari"]["font"]
    )

    passages = load_corpus(corpus_path)

    print(
        f"Loaded {len(passages)} corpus passages."
    )

    # --------------------------------------------------------
    # Background
    # --------------------------------------------------------

    background_type = rng.choice(
        config["background"]["types"]
    )

    background_generator = (
        ManuscriptBackgroundGenerator(
            width=width,
            height=height,
            seed=seed,
        )
    )

    image = background_generator.generate(
        background_type=background_type
    )

    # --------------------------------------------------------
    # Select many lines
    # --------------------------------------------------------

    lines = prepare_lines(
        passages,
        rng,
        target_lines=16,
    )

    # --------------------------------------------------------
    # Render text
    # --------------------------------------------------------

    metadata = render_manuscript(
        image=image,
        lines=lines,
        font_path=font_path,
        rng=rng,
        margin=config["layout"]["margin"],
    )

    # --------------------------------------------------------
    # Physical manuscript artifacts
    # --------------------------------------------------------

    image = add_manuscript_artifacts(
        image,
        rng,
    )

    # --------------------------------------------------------
    # Save
    # --------------------------------------------------------

    preview_dir = (
        ROOT
        / "output"
        / "preview"
    )

    preview_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    image_id = "manuscript_test"

    image_path = (
        preview_dir
        / f"{image_id}.png"
    )

    annotation_path = (
        preview_dir
        / f"{image_id}.md"
    )

    image.save(
        image_path,
        format="PNG",
    )

    source_text = "\n".join(lines)

    save_annotation(
        path=annotation_path,
        image_id=image_id,
        script="devanagari",
        source_text=source_text,
        metadata=metadata,
        background_type=background_type,
    )

    print()
    print("=" * 70)
    print("PREVIEW GENERATED")
    print("=" * 70)
    print()
    print(f"Image : {image_path}")
    print(f"MD    : {annotation_path}")
    print(f"Lines : {len(metadata)}")
    print(f"Background : {background_type}")
    print()
    print("Open the PNG and inspect it before generating 100 images.")
    print("=" * 70)


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("SYNTHETIC MANUSCRIPT GENERATOR")
    print("=" * 70)
    print()

    config = load_config()

    print(
        f"Project: "
        f"{config['project']['name']}"
    )

    print()

    generate_preview(config)


if __name__ == "__main__":
    main()